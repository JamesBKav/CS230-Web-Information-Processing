const pool = require('../db');

class User {
  static async create({ username, password, email, address }) {
    const sql = `INSERT INTO users (username, password, email, address) 
                 VALUES (?, ?, ?, ?)`;
    const [result] = await pool.query(sql, [username, password, email, address]);
    return result.insertId;
  }

  static async findByUsername(username) {
    const sql = `SELECT * FROM users WHERE username = ?`;
    const [rows] = await pool.query(sql, [username]);
    return rows[0];
  }

  static async findById(id) {
    const sql = `SELECT * FROM users WHERE id = ?`;
    const [rows] = await pool.query(sql, [id]);
    return rows[0];
  }

  static async addTravelLog(userId, logId) {
    const sql = `UPDATE users SET travel_logs = JSON_ARRAY_APPEND(IFNULL(travel_logs, JSON_ARRAY()), '$', ?) 
                 WHERE id = ?`;
    await pool.query(sql, [logId, userId]);
  }

  static async addJourneyPlan(userId, planId) {
    const sql = `UPDATE users SET journey_plans = JSON_ARRAY_APPEND(IFNULL(journey_plans, JSON_ARRAY()), '$', ?) 
                 WHERE id = ?`;
    await pool.query(sql, [planId, userId]);
  }
}

module.exports = User;