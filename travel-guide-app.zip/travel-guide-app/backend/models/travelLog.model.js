const pool = require('../db');

class TravelLog {
  static async create({ title, description, start_date, end_date, tags, user_id }) {
    const sql = `INSERT INTO travel_logs 
                 (title, description, start_date, end_date, post_date, tags, user_id) 
                 VALUES (?, ?, ?, ?, NOW(), ?, ?)`;
    const [result] = await pool.query(sql, [
      title, description, start_date, end_date, JSON.stringify(tags), user_id
    ]);
    return result.insertId;
  }

  static async findByUserId(userId) {
    const sql = `SELECT * FROM travel_logs WHERE user_id = ?`;
    const [rows] = await pool.query(sql, [userId]);
    return rows;
  }

  static async findById(id) {
    const sql = `SELECT * FROM travel_logs WHERE id = ?`;
    const [rows] = await pool.query(sql, [id]);
    return rows[0];
  }

  static async update(id, { title, description, start_date, end_date, tags }) {
    const sql = `UPDATE travel_logs 
                 SET title = ?, description = ?, start_date = ?, end_date = ?, tags = ?
                 WHERE id = ?`;
    await pool.query(sql, [title, description, start_date, end_date, JSON.stringify(tags), id]);
  }

  static async delete(id) {
    const sql = `DELETE FROM travel_logs WHERE id = ?`;
    await pool.query(sql, [id]);
  }
}

module.exports = TravelLog;