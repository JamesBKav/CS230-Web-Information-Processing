const pool = require('../db');

class JourneyPlan {
  static async create({ name, locations, start_date, end_date, activities, description, user_id }) {
    const sql = `INSERT INTO journey_plans 
                 (name, locations, start_date, end_date, activities, description, user_id) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)`;
    const [result] = await pool.query(sql, [
      name, JSON.stringify(locations), start_date, end_date, 
      JSON.stringify(activities), description, user_id
    ]);
    return result.insertId;
  }

  static async findByUserId(userId) {
    const sql = `SELECT * FROM journey_plans WHERE user_id = ?`;
    const [rows] = await pool.query(sql, [userId]);
    return rows;
  }

  static async findById(id) {
    const sql = `SELECT * FROM journey_plans WHERE id = ?`;
    const [rows] = await pool.query(sql, [id]);
    return rows[0];
  }

  static async update(id, { name, locations, start_date, end_date, activities, description }) {
    const sql = `UPDATE journey_plans 
                 SET name = ?, locations = ?, start_date = ?, end_date = ?, 
                     activities = ?, description = ?
                 WHERE id = ?`;
    await pool.query(sql, [
      name, JSON.stringify(locations), start_date, end_date, 
      JSON.stringify(activities), description, id
    ]);
  }

  static async delete(id) {
    const sql = `DELETE FROM journey_plans WHERE id = ?`;
    await pool.query(sql, [id]);
  }
}

module.exports = JourneyPlan;