const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const {
  getAllPlans,
  getPlan,
  createPlan,
  updatePlan,
  deletePlan
} = require('../controllers/journeyPlan.controller');

router.use(auth);
router.get('/', getAllPlans);
router.get('/:id', getPlan);
router.post('/', createPlan);
router.put('/:id', updatePlan);
router.delete('/:id', deletePlan);

module.exports = router;