const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');

const {
  getAllLogs,
  getLog,
  createLog,
  updateLog,
  deleteLog
} = require('../controllers/travelLog.controller');

router.use(auth);
router.get('/', getAllLogs);
router.get('/:id', getLog);
router.post('/', createLog);
router.put('/:id', updateLog);
router.delete('/:id', deleteLog);

module.exports = router;