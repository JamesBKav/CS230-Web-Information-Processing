const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    connectionLimit: 10,
    host: 'webcourse.cs.nuim.ie',
    user: 'u240289',
    password: 'caNoci7Eechah3ah',
    database: 'cs230_u240289',
    port: 3306
});
// Keep your existing helper functions and connection test
pool.queryAsync = async function(sql, params = []) {
    const [rows] = await this.query(sql, params);
    return rows;
};

pool.getAsync = async function(sql, params = []) {
    const [rows] = await this.query(sql, params);
    return rows[0] || null;
};

pool.runAsync = async function(sql, params = []) {
    const [result] = await this.query(sql, params);
    return result;
};

// Test database connection
(async () => {
    try {
        const conn = await pool.getConnection();
        console.log('✅ Database connection successful!');
        
        // Simple test query
        const [result] = await conn.query('SELECT 1 + 1 AS solution');
        console.log('Test query result:', result[0].solution);
        
        conn.release();
    } catch (err) {
        console.error('❌ Database connection failed:', err);
        process.exit(1);
    }
})();

module.exports = pool;