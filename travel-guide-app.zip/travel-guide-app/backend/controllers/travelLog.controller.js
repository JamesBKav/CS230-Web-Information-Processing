const TravelLog = require('../models/travelLog.model');

const getAllLogs = async (req, res) => {
  try {
    const logs = await TravelLog.findByUserId(req.userId);
    res.json(logs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getLog = async (req, res) => {
  try {
    const log = await TravelLog.findById(req.params.id);
    if (!log || log.user_id !== req.userId) {
      return res.status(404).json({ message: "Travel log not found" });
    }
    res.json(log);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const createLog = async (req, res) => {
  try {
    const { title, description, start_date, end_date, tags } = req.body;
    const logId = await TravelLog.create({
      title,
      description,
      start_date,
      end_date,
      tags: JSON.stringify(tags), 
      user_id: req.userId
    });

    res.status(201).json({ message: "Travel log created", logId });
  } catch (error) {
    console.error('Error in createLog:', error);
    res.status(500).json({ message: error.message });
  }
};


const updateLog = async (req, res) => {
  try {
    const log = await TravelLog.findById(req.params.id);
    if (!log || log.user_id !== req.userId) {
      return res.status(404).json({ message: "Travel log not found" });
    }

    await TravelLog.update(req.params.id, req.body);
    res.json({ message: "Travel log updated" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const deleteLog = async (req, res) => {
  try {
    const log = await TravelLog.findById(req.params.id);
    if (!log || log.user_id !== req.userId) {
      return res.status(404).json({ message: "Travel log not found" });
    }

    await TravelLog.delete(req.params.id);
    res.json({ message: "Travel log deleted" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllLogs,
  getLog,
  createLog,
  updateLog,
  deleteLog
};