const JourneyPlan = require('../models/journeyPlan.model');

const getAllPlans = async (req, res) => {
  try {
    const plans = await JourneyPlan.findByUserId(req.userId);
    res.json(plans);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getPlan = async (req, res) => {
  try {
    const plan = await JourneyPlan.findById(req.params.id);
    if (!plan || plan.user_id !== req.userId) {
      return res.status(404).json({ message: "Journey plan not found" });
    }
    res.json(plan);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const createPlan = async (req, res) => {
  try {
    const { name, locations, start_date, end_date, activities, description } = req.body;
    const planId = await JourneyPlan.create({
      name,
      locations: JSON.stringify(locations), 
      start_date,
      end_date,
      activities: JSON.stringify(activities), 
      description,
      user_id: req.userId
    });

    res.status(201).json({ message: "Journey plan created", planId });
  } catch (error) {
    console.error('Error in createPlan:', error);
    res.status(500).json({ message: error.message });
  }
};


const updatePlan = async (req, res) => {
  try {
    const plan = await JourneyPlan.findById(req.params.id);
    if (!plan || plan.user_id !== req.userId) {
      return res.status(404).json({ message: "Journey plan not found" });
    }

    await JourneyPlan.update(req.params.id, req.body);
    res.json({ message: "Journey plan updated" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const deletePlan = async (req, res) => {
  try {
    const plan = await JourneyPlan.findById(req.params.id);
    if (!plan || plan.user_id !== req.userId) {
      return res.status(404).json({ message: "Journey plan not found" });
    }

    await JourneyPlan.delete(req.params.id);
    res.json({ message: "Journey plan deleted" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllPlans,
  getPlan,
  createPlan,
  updatePlan,
  deletePlan
};