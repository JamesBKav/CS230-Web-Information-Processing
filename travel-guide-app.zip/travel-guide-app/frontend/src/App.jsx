import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { Container } from "react-bootstrap";
import Navigation from "./components/Navigation";
import LoginPage from "./pages/Login/LoginPage";
import TravelLogsPage from "./pages/TravelLogs/TravelLogsPage";
import JourneyPlansPage from "./pages/JourneyPlans/JourneyPlansPage";
import PrivateRoute from "./components/PrivateRoute";
import { AuthProvider } from "./context/AuthContext";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <Router>
      <AuthProvider>
        <Navigation />
        <Container className="mt-4">
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route
              path="/travel-logs"
              element={
                <PrivateRoute>
                  <TravelLogsPage />
                </PrivateRoute>
              }
            />
            <Route
              path="/journey-plans"
              element={
                <PrivateRoute>
                  <JourneyPlansPage />
                </PrivateRoute>
              }
            />
            <Route
              path="/"
              element={
                <PrivateRoute>
                  <TravelLogsPage />
                </PrivateRoute>
              }
            />
          </Routes>
        </Container>
      </AuthProvider>
    </Router>
  );
}

export default App;
