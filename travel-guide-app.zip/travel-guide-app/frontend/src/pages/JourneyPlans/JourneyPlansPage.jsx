import React, { useState, useEffect } from "react";
import {
  Button,
  Card,
  Col,
  Container,
  Form,
  Modal,
  Row,
  Table,
} from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus, faEdit, faTrash } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import { useAuth } from "../../context/AuthContext";

const JourneyPlansPage = () => {
  const { user } = useAuth();
  const [plans, setPlans] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    locations: [],
    start_date: "",
    end_date: "",
    activities: [],
    description: "",
  });
  const [newLocation, setNewLocation] = useState("");
  const [newActivity, setNewActivity] = useState("");

  useEffect(() => {
    if (user) {
      fetchPlans();
    }
  }, [user]);

  const fetchPlans = async () => {
    try {
      const response = await axios.get("/journey-plans", {
        withCredentials: true,
      });
      setPlans(response.data);
    } catch (error) {
      console.error("Error fetching journey plans:", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleAddLocation = () => {
    if (
      newLocation.trim() &&
      !formData.locations.includes(newLocation.trim())
    ) {
      setFormData({
        ...formData,
        locations: [...formData.locations, newLocation.trim()],
      });
      setNewLocation("");
    }
  };

  const handleRemoveLocation = (locationToRemove) => {
    setFormData({
      ...formData,
      locations: formData.locations.filter(
        (location) => location !== locationToRemove
      ),
    });
  };

  const handleAddActivity = () => {
    if (
      newActivity.trim() &&
      !formData.activities.includes(newActivity.trim())
    ) {
      setFormData({
        ...formData,
        activities: [...formData.activities, newActivity.trim()],
      });
      setNewActivity("");
    }
  };

  const handleRemoveActivity = (activityToRemove) => {
    setFormData({
      ...formData,
      activities: formData.activities.filter(
        (activity) => activity !== activityToRemove
      ),
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingPlan) {
        await axios.put(`/journey-plans/${editingPlan.id}`, formData, {
          withCredentials: true,
        });
      } else {
        await axios.post("/journey-plans", formData, {
          withCredentials: true,
        });
      }
      fetchPlans();
      handleCloseModal();
    } catch (error) {
      console.error("Error saving journey plan:", error);
    }
  };

  const handleEdit = (plan) => {
    setEditingPlan(plan);
    setFormData({
      name: plan.name,
      locations: plan.locations || [],
      start_date: plan.start_date.split("T")[0],
      end_date: plan.end_date.split("T")[0],
      activities: plan.activities || [],
      description: plan.description,
    });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this journey plan?")) {
      try {
        await axios.delete(`/journey-plans/${id}`, {
          withCredentials: true,
        });
        fetchPlans();
      } catch (error) {
        console.error("Error deleting journey plan:", error);
      }
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingPlan(null);
    setFormData({
      name: "",
      locations: [],
      start_date: "",
      end_date: "",
      activities: [],
      description: "",
    });
  };

  return (
    <Container>
      <Row className="mb-4">
        <Col>
          <h2>Journey Plans</h2>
        </Col>
        <Col className="text-end">
          <Button variant="primary" onClick={() => setShowModal(true)}>
            <FontAwesomeIcon icon={faPlus} className="me-2" />
            Add Journey Plan
          </Button>
        </Col>
      </Row>

      {plans.length === 0 ? (
        <Card>
          <Card.Body className="text-center">
            <p>No journey plans found. Add your first journey plan!</p>
          </Card.Body>
        </Card>
      ) : (
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Name</th>
              <th>Locations</th>
              <th>Dates</th>
              <th>Activities</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {plans.map((plan) => (
              <tr key={plan.id}>
                <td>{plan.name}</td>
                <td>
                  {Array.isArray(plan.locations)
                    ? plan.locations.map((location) => (
                        <span
                          key={location}
                          className="badge bg-secondary me-1"
                        >
                          {location}
                        </span>
                      ))
                    : null}
                </td>
                <td>
                  {new Date(plan.start_date).toLocaleDateString()} -{" "}
                  {new Date(plan.end_date).toLocaleDateString()}
                </td>
                <td>
                  {Array.isArray(plan.activities)
                    ? plan.activities.map((activity) => (
                        <span key={activity} className="badge bg-info me-1">
                          {activity}
                        </span>
                      ))
                    : null}
                </td>
                <td>
                  <Button
                    variant="info"
                    size="sm"
                    className="me-2"
                    onClick={() => handleEdit(plan)}
                  >
                    <FontAwesomeIcon icon={faEdit} />
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => handleDelete(plan.id)}
                  >
                    <FontAwesomeIcon icon={faTrash} />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>
            {editingPlan ? "Edit Journey Plan" : "Add Journey Plan"}
          </Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmit}>
          <Modal.Body>
            <Form.Group className="mb-3">
              <Form.Label>Plan Name</Form.Label>
              <Form.Control
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
              />
            </Form.Group>
            <Row className="mb-3">
              <Col>
                <Form.Group>
                  <Form.Label>Start Date</Form.Label>
                  <Form.Control
                    type="date"
                    name="start_date"
                    value={formData.start_date}
                    onChange={handleInputChange}
                    required
                  />
                </Form.Group>
              </Col>
              <Col>
                <Form.Group>
                  <Form.Label>End Date</Form.Label>
                  <Form.Control
                    type="date"
                    name="end_date"
                    value={formData.end_date}
                    onChange={handleInputChange}
                    required
                  />
                </Form.Group>
              </Col>
            </Row>
            <Form.Group className="mb-3">
              <Form.Label>Locations</Form.Label>
              <div className="d-flex mb-2">
                <Form.Control
                  type="text"
                  value={newLocation}
                  onChange={(e) => setNewLocation(e.target.value)}
                  placeholder="Add a location"
                />
                <Button
                  variant="secondary"
                  onClick={handleAddLocation}
                  className="ms-2"
                >
                  Add
                </Button>
              </div>
              <div>
                {formData.locations.map((location) => (
                  <span key={location} className="badge bg-primary me-1">
                    {location}
                    <button
                      type="button"
                      className="btn-close btn-close-white ms-1"
                      style={{ fontSize: "0.5rem" }}
                      onClick={() => handleRemoveLocation(location)}
                      aria-label="Remove"
                    />
                  </span>
                ))}
              </div>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Activities</Form.Label>
              <div className="d-flex mb-2">
                <Form.Control
                  type="text"
                  value={newActivity}
                  onChange={(e) => setNewActivity(e.target.value)}
                  placeholder="Add an activity"
                />
                <Button
                  variant="secondary"
                  onClick={handleAddActivity}
                  className="ms-2"
                >
                  Add
                </Button>
              </div>
              <div>
                {formData.activities.map((activity) => (
                  <span key={activity} className="badge bg-success me-1">
                    {activity}
                    <button
                      type="button"
                      className="btn-close btn-close-white ms-1"
                      style={{ fontSize: "0.5rem" }}
                      onClick={() => handleRemoveActivity(activity)}
                      aria-label="Remove"
                    />
                  </span>
                ))}
              </div>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="description"
                value={formData.description}
                onChange={handleInputChange}
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCloseModal}>
              Close
            </Button>
            <Button variant="primary" type="submit">
              Save Changes
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </Container>
  );
};

export default JourneyPlansPage;
