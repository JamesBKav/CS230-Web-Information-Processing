import React, { useState, useEffect } from "react";
import {
  Button,
  Card,
  Col,
  Container,
  Form,
  Modal,
  Row,
  Table,
} from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus, faEdit, faTrash } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import { useAuth } from "../../context/AuthContext";

const TravelLogsPage = () => {
  const { user } = useAuth();
  const [logs, setLogs] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingLog, setEditingLog] = useState(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    start_date: "",
    end_date: "",
    tags: [],
  });
  const [newTag, setNewTag] = useState("");

  useEffect(() => {
    if (user) {
      fetchLogs();
    }
  }, [user]);

  const fetchLogs = async () => {
    try {
      const response = await axios.get("/travel-logs", {
        withCredentials: true,
      });
      setLogs(response.data);
    } catch (error) {
      console.error("Error fetching travel logs:", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleAddTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, newTag.trim()],
      });
      setNewTag("");
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter((tag) => tag !== tagToRemove),
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingLog) {
        await axios.put(`/travel-logs/${editingLog.id}`, formData, {
          withCredentials: true,
        });
      } else {
        await axios.post("/travel-logs", formData, {
          withCredentials: true,
        });
      }
      fetchLogs();
      handleCloseModal();
    } catch (error) {
      console.error("Error saving travel log:", error);
    }
  };

  const handleEdit = (log) => {
    setEditingLog(log);
    setFormData({
      title: log.title,
      description: log.description,
      start_date: log.start_date.split("T")[0],
      end_date: log.end_date.split("T")[0],
      tags: log.tags || [],
    });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this travel log?")) {
      try {
        await axios.delete(`/travel-logs/${id}`, { withCredentials: true });
        fetchLogs();
      } catch (error) {
        console.error("Error deleting travel log:", error);
      }
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingLog(null);
    setFormData({
      title: "",
      description: "",
      start_date: "",
      end_date: "",
      tags: [],
    });
  };

  return (
    <Container>
      <Row className="mb-4">
        <Col>
          <h2>Travel Logs</h2>
        </Col>
        <Col className="text-end">
          <Button variant="primary" onClick={() => setShowModal(true)}>
            <FontAwesomeIcon icon={faPlus} className="me-2" />
            Add Travel Log
          </Button>
        </Col>
      </Row>

      {logs.length === 0 ? (
        <Card>
          <Card.Body className="text-center">
            <p>No travel logs found. Add your first travel log!</p>
          </Card.Body>
        </Card>
      ) : (
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Title</th>
              <th>Description</th>
              <th>Dates</th>
              <th>Tags</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log) => (
              <tr key={log.id}>
                <td>{log.title}</td>
                <td>{log.description}</td>
                <td>
                  {new Date(log.start_date).toLocaleDateString()} -{" "}
                  {new Date(log.end_date).toLocaleDateString()}
                </td>
                <td>
                  {Array.isArray(log.tags)
                    ? log.tags.map((tag) => (
                        <span key={tag} className="badge bg-secondary me-1">
                          {tag}
                        </span>
                      ))
                    : null}
                </td>
                <td>
                  <Button
                    variant="info"
                    size="sm"
                    className="me-2"
                    onClick={() => handleEdit(log)}
                  >
                    <FontAwesomeIcon icon={faEdit} />
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => handleDelete(log.id)}
                  >
                    <FontAwesomeIcon icon={faTrash} />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>
            {editingLog ? "Edit Travel Log" : "Add Travel Log"}
          </Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmit}>
          <Modal.Body>
            <Form.Group className="mb-3">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="description"
                value={formData.description}
                onChange={handleInputChange}
              />
            </Form.Group>
            <Row className="mb-3">
              <Col>
                <Form.Group>
                  <Form.Label>Start Date</Form.Label>
                  <Form.Control
                    type="date"
                    name="start_date"
                    value={formData.start_date}
                    onChange={handleInputChange}
                    required
                  />
                </Form.Group>
              </Col>
              <Col>
                <Form.Group>
                  <Form.Label>End Date</Form.Label>
                  <Form.Control
                    type="date"
                    name="end_date"
                    value={formData.end_date}
                    onChange={handleInputChange}
                    required
                  />
                </Form.Group>
              </Col>
            </Row>
            <Form.Group className="mb-3">
              <Form.Label>Tags</Form.Label>
              <div className="d-flex mb-2">
                <Form.Control
                  type="text"
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  placeholder="Add a tag"
                />
                <Button
                  variant="secondary"
                  onClick={handleAddTag}
                  className="ms-2"
                >
                  Add
                </Button>
              </div>
              <div>
                {formData.tags.map((tag) => (
                  <span key={tag} className="badge bg-primary me-1">
                    {tag}
                    <button
                      type="button"
                      className="btn-close btn-close-white ms-1"
                      style={{ fontSize: "0.5rem" }}
                      onClick={() => handleRemoveTag(tag)}
                      aria-label="Remove"
                    />
                  </span>
                ))}
              </div>
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCloseModal}>
              Close
            </Button>
            <Button variant="primary" type="submit">
              Save Changes
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </Container>
  );
};

export default TravelLogsPage;
