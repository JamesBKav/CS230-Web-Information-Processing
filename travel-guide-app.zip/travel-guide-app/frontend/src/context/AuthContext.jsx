import React, { createContext, useState, useEffect } from "react";
import axios from "axios";

const AuthContext = createContext();

axios.defaults.baseURL = "http://localhost:5000/api";
axios.defaults.withCredentials = true;

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem("token");
        if (token) {
          axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
          const response = await axios.get("/auth/user");
          setUser(response.data);
        }
      } catch (error) {
        console.error("Auth check failed", error);
        logout();
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (username, password) => {
    const response = await axios.post("/auth/login", {
      username,
      password,
    });
    localStorage.setItem("token", response.data.token);
    axios.defaults.headers.common[
      "Authorization"
    ] = `Bearer ${response.data.token}`;
    setUser({ username: response.data.username, userId: response.data.userId });
  };

  const register = async (username, password, email, address) => {
    await axios.post("/auth/register", {
      username,
      password,
      email,
      address,
    });
    await login(username, password);
  };

  const logout = () => {
    localStorage.removeItem("token");
    delete axios.defaults.headers.common["Authorization"];
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => React.useContext(AuthContext);
